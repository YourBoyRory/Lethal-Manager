This is a beta for the windows package
install anywhere, just make sure the JRE folder is in the same directory as the executable

because the exe is unsigned you will have to allow the exe by selecting "more info" and then "allow anyways"

when the full windows release comes out the exe will be signed and this package will have a installer
